// Dante Howard
// 5-21-19

public class sampleClass 
{
  int x = 5;

  public static void main(String[] args)
  {
    
    sampleClass myObj = new sampleClass();
    sampleClass myObj2 = new sampleClass();
    
    myObj.x = 8;
    
    System.out.println(myObj.x);
    System.out.println(myObj2.x);
  }
}