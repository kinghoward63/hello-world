//Dante Howard
//5-27-19
public class Die
{
   private int lastValue;
   private ArrayList<Integer> die_list = new Arraylist<Integer>(8);

   public int roll()
   {
      lastValue = (int) (Math.random() * 6) + 1;
      die_list.add(lastVaule);
      return lastValue;
   }

   public static void main(String[] args)
   {
      Die d = new Die();
      for (int i = 0; i < 10; i++)
      {
         System.out.println(d.roll());
      }
   }
}  